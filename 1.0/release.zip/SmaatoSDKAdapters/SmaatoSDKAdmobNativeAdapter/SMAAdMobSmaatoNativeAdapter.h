//
//  SMAAdMobSmaatoNativeAdapter.h
//  SmaatoSDKAdmobNativeAdapter
//
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface SMAAdMobSmaatoNativeAdapter: NSObject
@property (class, nonatomic, readonly) NSString *version;
@end
