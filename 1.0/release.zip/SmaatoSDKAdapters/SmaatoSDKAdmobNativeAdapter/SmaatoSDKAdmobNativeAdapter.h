//
//  SmaatoSDKAdmobNativeAdapter.h
//  SmaatoSDKAdmobNativeAdapter
//
//  Created by Ashwinee on 28/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SmaatoSDKAdmobNativeAdapter.
FOUNDATION_EXPORT double SmaatoSDKAdmobNativeAdapterVersionNumber;

//! Project version string for SmaatoSDKAdmobNativeAdapter.
FOUNDATION_EXPORT const unsigned char SmaatoSDKAdmobNativeAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKAdmobNativeAdapter/PublicHeader.h>


