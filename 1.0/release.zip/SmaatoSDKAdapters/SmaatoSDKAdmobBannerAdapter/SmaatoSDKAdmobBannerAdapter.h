//
//  SmaatoSDKAdmobBannerAdapter.h
//  SmaatoSDKAdmobBannerAdapter
//
//  Created by Ashwinee on 27/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SmaatoSDKAdmobBannerAdapter.
FOUNDATION_EXPORT double SmaatoSDKAdmobBannerAdapterVersionNumber;

//! Project version string for SmaatoSDKAdmobBannerAdapter.
FOUNDATION_EXPORT const unsigned char SmaatoSDKAdmobBannerAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKAdmobBannerAdapter/PublicHeader.h>


