//
//  SmaatoSDKAdmobRewardedVideoAdapter.h
//  SmaatoSDKAdmobRewardedVideoAdapter
//
//  Created by Ashwinee on 28/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SmaatoSDKAdmobRewardedVideoAdapter.
FOUNDATION_EXPORT double SmaatoSDKAdmobRewardedVideoAdapterVersionNumber;

//! Project version string for SmaatoSDKAdmobRewardedVideoAdapter.
FOUNDATION_EXPORT const unsigned char SmaatoSDKAdmobRewardedVideoAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKAdmobRewardedVideoAdapter/PublicHeader.h>


