//
//  SmaatoSDKApplovinWaterfallAdapter.h
//  SmaatoSDKApplovinWaterfallAdapter
//
//  Created by Ashwinee on 28/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SmaatoSDKApplovinWaterfallAdapter.
FOUNDATION_EXPORT double SmaatoSDKApplovinWaterfallAdapterVersionNumber;

//! Project version string for SmaatoSDKApplovinWaterfallAdapter.
FOUNDATION_EXPORT const unsigned char SmaatoSDKApplovinWaterfallAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKApplovinWaterfallAdapter/PublicHeader.h>


