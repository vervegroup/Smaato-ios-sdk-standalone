//
//  SmaatoSDKAdmobInterstitialAdapter.h
//  SmaatoSDKAdmobInterstitialAdapter
//
//  Created by Ashwinee on 28/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SmaatoSDKAdmobInterstitialAdapter.
FOUNDATION_EXPORT double SmaatoSDKAdmobInterstitialAdapterVersionNumber;

//! Project version string for SmaatoSDKAdmobInterstitialAdapter.
FOUNDATION_EXPORT const unsigned char SmaatoSDKAdmobInterstitialAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKAdmobInterstitialAdapter/PublicHeader.h>


