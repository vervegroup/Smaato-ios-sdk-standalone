//
//  SmaatoSDKInterstitial.h
//  SmaatoSDKInterstitial
//
//  Created by Ashwinee on 24/03/25.
//

#import <Foundation/Foundation.h>
#import <SmaatoSDKInterstitial/SMAInterstitial.h>
#import <SmaatoSDKInterstitial/SmaatoSDK+Interstitial.h>

//! Project version number for SmaatoSDKInterstitial.
FOUNDATION_EXPORT double SmaatoSDKInterstitialVersionNumber;

//! Project version string for SmaatoSDKInterstitial.
FOUNDATION_EXPORT const unsigned char SmaatoSDKInterstitialVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKInterstitial/PublicHeader.h>


