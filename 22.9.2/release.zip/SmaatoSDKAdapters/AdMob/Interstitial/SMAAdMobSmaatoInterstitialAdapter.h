//
//  SMAAdMobSmaatoInterstitialAdapter.h
//  SmaatoSDKAdmobInterstitialAdapter
//
//

#import <Foundation/Foundation.h>

@interface SMAAdMobSmaatoInterstitialAdapter: NSObject
@property (class, nonatomic, readonly) NSString *version;
@end
