//
//  SMAAdMobSmaatoBannerAdapter.h
//  SMAAdMobSmaatoBannerAdapter
//
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface SMAAdMobSmaatoBannerAdapter: NSObject <GADMediationAdapter>
@property (class, nonatomic, readonly) NSString *version;
@end
