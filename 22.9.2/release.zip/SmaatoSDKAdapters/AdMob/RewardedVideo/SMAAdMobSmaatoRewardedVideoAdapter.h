//
//  SMAAdMobSmaatoRewardedVideoAdapter.h
//  SmaatoSDKAdmobRewardedVideoAdapter
//
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface SMAAdMobSmaatoRewardedVideoAdapter: NSObject <GADMediationAdapter>
@property (class, nonatomic, readonly) NSString *version;
@end
