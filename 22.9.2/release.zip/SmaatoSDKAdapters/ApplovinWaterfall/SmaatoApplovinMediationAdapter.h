//
//  SmaatoApplovinMediationAdapter.h
//  SmaatoSDKApplovinWaterfallAdapter
//
//  Created by Ashwinee on 28/03/25.
//

#import <AppLovinSDK/AppLovinSDK.h>

@interface SmaatoApplovinMediationAdapter:ALMediationAdapter<MAAdViewAdapter, MAInterstitialAdapter, MARewardedAdapter>

@end
