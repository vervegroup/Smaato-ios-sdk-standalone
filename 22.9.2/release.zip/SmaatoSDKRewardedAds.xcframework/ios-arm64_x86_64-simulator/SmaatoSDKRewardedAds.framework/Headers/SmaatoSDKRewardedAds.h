//
//  SmaatoSDKRewardedAds.h
//  SmaatoSDKRewardedAds
//
//  Created by Ashwinee on 24/03/25.
//

#import <Foundation/Foundation.h>
#import <SmaatoSDKRewardedAds/SMARewardedInterstitial.h>
#import <SmaatoSDKRewardedAds/SmaatoSDK+RewardedAds.h>

//! Project version number for SmaatoSDKRewardedAds.
FOUNDATION_EXPORT double SmaatoSDKRewardedAdsVersionNumber;

//! Project version string for SmaatoSDKRewardedAds.
FOUNDATION_EXPORT const unsigned char SmaatoSDKRewardedAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKRewardedAds/PublicHeader.h>


