//
//  SmaatoSDKInAppBidding.h
//  SmaatoSDKInAppBidding
//
//  Created by Ashwinee on 24/03/25.
//

#import <Foundation/Foundation.h>
#import <SmaatoSDKInAppBidding/SMAInAppBid.h>
#import <SmaatoSDKInAppBidding/SMAInAppBidding.h>

//! Project version number for SmaatoSDKInAppBidding.
FOUNDATION_EXPORT double SmaatoSDKInAppBiddingVersionNumber;

//! Project version string for SmaatoSDKInAppBidding.
FOUNDATION_EXPORT const unsigned char SmaatoSDKInAppBiddingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmaatoSDKInAppBidding/PublicHeader.h>


